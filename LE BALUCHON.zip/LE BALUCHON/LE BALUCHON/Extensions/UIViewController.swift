//
//  UIViewController.swift
//  LE BALUCHON
//
//  Created by Sebastien Bastide on 05/08/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import UIKit

//MARK: Methods

extension UIViewController {
    
    // Method to display an alert
    func alert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style:.default, handler: nil)
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    // Method called to manage button and activity controller together: true to hide button and show acticity indicator / false to show button and hide activity controller
    func activityIndicator(activityIndicator: UIActivityIndicatorView, button: UIButton, showActivityIndicator: Bool){
        activityIndicator.isHidden = !showActivityIndicator
        button.isHidden = showActivityIndicator
    }
    
    // Currency to convert to string
    func convertToString(value: Float) -> String {
        return String(value)
    }
}
