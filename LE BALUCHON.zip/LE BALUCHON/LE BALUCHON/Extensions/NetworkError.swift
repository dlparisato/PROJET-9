//
//  ErrorCases.swift
//  LE BALUCHON
//
//  Created by PARISATO on 07/08/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

//MARK: Enumeration to manage errors

enum NetworkError: Error {
    case noData
    case noResponse
    case undecodable
}
