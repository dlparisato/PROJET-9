//
//  UITextView.swift
//  LE BALUCHON
//
//  Created by Sebastien Bastide on 05/08/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import UIKit

// MARK: Extension to align in center the textView

extension UITextView {
    func centerVertically() {
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale) / 2
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
    }
}
