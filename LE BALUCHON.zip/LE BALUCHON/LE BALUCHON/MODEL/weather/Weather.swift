//
//  Weather.swift
//  LE BALUCHON
//
//  Created by PARISATO on 26/07/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

//MARK: Structures to manage the data

struct WeatherInfo: Decodable {
    let weather: [Weather]
    let main: Main
}

struct Weather: Decodable {
    let main: String
    let description: String
}

struct Main: Decodable {
    let temp: Float
}
