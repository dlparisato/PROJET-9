//
//  WeatherService.swift
//  LE BALUCHON
//
//  Created by PARISATO on 17/06/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

final class WeatherService {
    
    // MARK:  PROPERTIES
    
    // URLSessionDataTask
    private var task: URLSessionDataTask?
    
    // URLSession and initialisation
    private var weatherSession = URLSession(configuration: .default)
    init(weatherSession: URLSession = URLSession(configuration: .default)) {
        self.weatherSession = weatherSession
    }
    
    // MARK: - METHODS
    
    // Send a request to the OpenWeatherMap API and return this response
    func getWeather(from city: String, callback: @escaping (Result<WeatherInfo, NetworkError>) -> Void) {
        
        /// Stock city demanded by user and add it to the URL
        guard let encodedCity = city.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) else { return }
        
        /// Compose URL
        guard let weatherURL = URL(string: "http://api.openweathermap.org/data/2.5/weather?q=\(encodedCity)&APPID=\(ApiKey.openWeatherMap)&units=metric") else { return }
        
        task = weatherSession.dataTask(with: weatherURL) { (data, response, error) in
            
            /// Check error
            guard let data = data, error == nil else {
                callback(.failure(.noData))
                return
            }
            
            /// Check status response
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                callback(.failure(.noResponse))
                return
            }
            
            /// Check response JSON
            guard let responseJSON = try? JSONDecoder().decode(WeatherInfo.self, from: data) else {
                callback(.failure(.undecodable))
                return
            }
            print(responseJSON)
            callback(.success(responseJSON))
        }
        task?.resume()
    }
}


