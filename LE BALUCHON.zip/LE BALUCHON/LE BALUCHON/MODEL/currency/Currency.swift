//
//  Currency.swift
//  LE BALUCHON
//
//  Created by PARISATO on 25/07/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

//MARK: Structures to manage the data

struct Currency: Decodable {
    var rates: [String: Double]
    /// Convert Euro -> Dollar
    private func convertFromEuro(value: Double, rate: Double) -> Double {
        /// Euro multiply convert Exchange Rate = Dolar value
        return value * rate
    }
    
    /// Result dollar value
    func convert(value: Double, from: String, to: String) -> Double {
        guard let rate = rates[to] else { return 0.00 }
        let convertValue = convertFromEuro(value: value, rate: rate)
        return convertValue
    }
}
