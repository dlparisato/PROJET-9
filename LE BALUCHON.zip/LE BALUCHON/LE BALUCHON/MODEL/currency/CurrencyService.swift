//
//  CurrencyService.swift
//  LE BALUCHON
//
//  Created by PARISATO on 17/06/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

final class CurrencyService {
    
    // MARK: PROPERTIES
    
    /// URLSessionsDataTask
    private var task: URLSessionDataTask?
    
    /// URLSession
    private var currencySession: URLSession
    
    /// initialiaze URLSession
    init(currencySession: URLSession = URLSession(configuration: .default)) {
        self.currencySession = currencySession
    }
    
    // MARK: - METHODS
    
    /// Send a request to Fixer API and return response
    func getRate(callback: @escaping (Result<Currency, NetworkError>) -> Void) {
        
        /// Stock API key
        let apiKey = ApiKey.fixer
        
        /// Compose URL
        guard let currencyURL = URL(string: "http://data.fixer.io/api/latest?access_key=\(apiKey)&base=EUR&symbols=USD") else { return }
        print(currencyURL)
        
        /// Give the session a task
        task?.cancel()
        task = currencySession.dataTask(with: currencyURL) { (data, response, error) in
            
            /// check error
            guard let data = data, error == nil else {
                callback(.failure(.noData))
                return
            }
            
            /// check status response
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                callback(.failure(.noResponse))
                return
            }
            
            /// check response JSON
            guard let responseJSON = try? JSONDecoder().decode(Currency.self, from: data) else {
                callback(.failure(.undecodable))
                return
            }
            callback(.success(responseJSON))
        }
        task?.resume()
    }
}
