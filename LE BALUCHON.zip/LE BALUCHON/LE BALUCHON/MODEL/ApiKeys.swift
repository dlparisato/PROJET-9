//
//  ApiKeys.swift
//  LE BALUCHON
//
//  Created by PARISATO on 25/07/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

//Mettre votre cle API dans ""
struct ApiKey {
    static let fixer: String = ""
    static let openWeatherMap: String = ""
    static let googleTranslate: String = ""
}
