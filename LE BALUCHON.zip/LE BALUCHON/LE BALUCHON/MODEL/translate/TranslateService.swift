//
//  TranslateService.swift
//  LE BALUCHON
//
//  Created by PARISATO on 17/06/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

enum Language {
    case fr
    case en
    case detect
}

final class TranslateService {
    
    //  MARK: PROPERTIES
    
    let language: [String] = ["Français -> Anglais", "Anglais -> Français", "Detection -> Français"]
    
    // source language
    private var source: String = "fr"
    
    // target language
    private var target: String = "en"
    
    // URLSession
    private var translateSession: URLSession
    
    // URLSessionsDataTask
    private var task: URLSessionDataTask?
    
    // initialiaze URLSession
    init(translateSession: URLSession = URLSession(configuration: .default)) {
        self.translateSession = translateSession
    }
    
    // MARK: - METHODS
    
    // Send a request to the Google Translate API and return response
    func getTranslate(language: Language, text: String, callback: @escaping (Result <Translate, NetworkError>) -> Void) {
        
        /// Compose URL
        guard let request = createTranslateRequest(text: text, language: language) else { return }
        
        /// Give the session a task
        task?.cancel()
        task = translateSession.dataTask(with: request) { (data, response, error) in
            
            /// Check error
            guard let data = data, error == nil else {
                callback(.failure(.noData))
                return
            }
            
            /// Check status response
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                callback(.failure(.noResponse))
                return
            }
            
            /// Check response JSON
            guard let responseJSON = try? JSONDecoder().decode(Translate.self, from: data) else {
                callback(.failure(.undecodable))
                return
            }
            callback(.success(responseJSON))
            return
        }
        task?.resume()
    }
    
    // Create a request based with parameter
    private func createTranslateRequest(text: String, language: Language) -> URLRequest? {
        
        /// Stock API Key
        let apiKey = ApiKey.googleTranslate
        
        /// Compose URL
        guard let translateURL = URL(string: "https://translation.googleapis.com/language/translate/v2?key=\(apiKey)") else { return nil }
        var request = URLRequest(url: translateURL)
        request.httpMethod = "POST"
        
        /// Stock text to translate
        let q: String = text
        selectedLanguage(language: language)
        
        /// Stock body of the request with text, source, target and APIkey
        let body = "q=\(q)" + "&\(source)" + "&target=\(target)" + "&key=\(ApiKey.googleTranslate)&format=text"
        request.httpBody = body.data(using: .utf8)
        return request
    }
    
    // Change source and target by the index
    private func selectedLanguage(language: Language) {
        switch language {
        case .fr :
            source = "source=fr"
            target = "en"
        case .en :
            source = "source=en"
            target = "fr"
        case .detect :
            source = "detect"
            target = "fr"
        }
    }
}

 

