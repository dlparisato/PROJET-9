//
//  Translate.swift
//  LE BALUCHON
//
//  Created by PARISATO on 25/07/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation


//MARK: Structures to manage the data


struct Translate: Decodable {
    var data: TranslationData
}

struct TranslationData: Decodable {
    var translations: [TranslationText]
}

struct TranslationText: Decodable {
    var translatedText: String
}



