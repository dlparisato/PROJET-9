//
//  WeatherView.swift
//  LE BALUCHON
//
//  Created by PARISATO on 29/07/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import UIKit

class WeatherView: UIView {
    // Stock images with their key
    static let icon: [String: UIImage] = ["Mist": #imageLiteral(resourceName: "Mist")  , "Haze": #imageLiteral(resourceName: "Fog") , "Clouds":#imageLiteral(resourceName: "Clouds") , "Lighting":#imageLiteral(resourceName: "Lightning") , "Rain":#imageLiteral(resourceName: "Rain") , "Snow": #imageLiteral(resourceName: "Snow"), "Clear":#imageLiteral(resourceName: "Clear"),"Drizzle":#imageLiteral(resourceName: "Drizzle_"),"Fog":#imageLiteral(resourceName: "Haze") ]
}
