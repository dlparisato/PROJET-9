//
//  CurrencyViewController.swift
//  LE BALUCHON
//
//  Created by DL PARISATO on 15/06/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import UIKit

class CurrencyViewController: UIViewController {
    
    // MARK: OUTLETS
  
    // TextFiel and Label
    @IBOutlet weak var euroTextField: UITextField!
    @IBOutlet weak var dollarLabel: UILabel!
    
    // Activity Indicator and Button
    @IBOutlet weak var activityIndicatorButton: UIActivityIndicatorView!
    @IBOutlet weak var validButton: UIButton!
    
    // MARK: - ACTION
    
    // Check if there's value to convert
    @IBAction func tappedValidButton(_ sender: UIButton) {
        guard euroTextField.text != "", euroTextField.text != "," else {
            /// Send an alert to enter a value to convert
            alert(title: "Erreur", message: "Entrez un montant !")
            return
        }
        convertCurrency()
    }
    
    // MARK: - PROPERTIES
        
    // Instance of the symbols
    private let fromEuro = "EUR"
    private let toDollar = "USD"
    
    // Instance of the CurrencyService class
    private let currencyService = CurrencyService()
    
    // MARK: - VIEW LIFE CYCLE: Hide activityIndicator
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activityIndicator(activityIndicator: activityIndicatorButton, button: validButton, showActivityIndicator: false)
    }
    
    // MARK: - METHODS
    
    // Method to convert
    private func convertCurrency() {
        /// Change type of the value in Double for the call
        guard let text = euroTextField.text, let value = Double(text) else { return }
        
        /// Show activityIndicator when we send the request to the API
        activityIndicator(activityIndicator: activityIndicatorButton, button: validButton, showActivityIndicator: true)
        
        /// Call API to send request
        currencyService.getRate { [unowned self] result in
            DispatchQueue.main.async {
                /// Hide activityIndicator when we get the result
                self.activityIndicator(activityIndicator: self.activityIndicatorButton, button: self.validButton, showActivityIndicator: false)
                /// Manage the result success or failure
                switch result {
                /// Display the value converted
                case .success(let currency):
                    self.displayWithTwoDecimals(result: currency.convert(value: value, from: self.fromEuro, to: self.toDollar))
                /// Send an alert that the exchange doesn't work
                case .failure:
                    self.alert(title: "Erreur", message: "Impossible de convertir, vérifier la connexion internet ")
                }
            }
        }
    }
    
    // Method to display result with two decimals
    private func displayWithTwoDecimals(result: Double){
        let result = String(format: "%.2f", result)
        dollarLabel.text = result
    }
}

// MARK: - EXTENSIONS

// Extension to dismiss Keyboard
extension CurrencyViewController: UITextFieldDelegate {
    @IBAction func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        euroTextField.resignFirstResponder()
    }
}

