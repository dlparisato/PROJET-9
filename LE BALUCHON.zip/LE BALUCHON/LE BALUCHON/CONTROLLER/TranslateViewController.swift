//
//  WeatherViewController.swift
//  LE BALUCHON
//
//  Created by DL PARISATO on 15/06/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//


import UIKit

class TranslateViewController: UIViewController {
    
    // MARK:  OUTLETS
    
    // Languages
    @IBOutlet private weak var sourceLabel: UILabel!
    @IBOutlet private weak var targetLabel: UILabel!
    
    // Text and Translation
    @IBOutlet private weak var text: UITextField!
    @IBOutlet private weak var translation: UITextView!
    
    // Picker View
    @IBOutlet private weak var languagePickerView: UIPickerView!
    
    // Button and Activity Indicator
    @IBOutlet private weak var validButton: UIButton!
    @IBOutlet weak var activityIndicatorButton: UIActivityIndicatorView!
    
    // MARK:- PROPERTIES
    
    // Instance of the TranslateService class
    private let translateService = TranslateService()
    
    // instance of index
    private var index: Int = 0
    
    // instance of type language
    private var language: Language = .fr
    
    // MARK: - VIEW LIFE CYCLE: Hide the activity indicator
    
    override func viewDidLoad() {
        // Align textField
        text.textAlignment = .natural
        // Hide activity indicator and display button
        activityIndicator(activityIndicator: activityIndicatorButton, button: validButton, showActivityIndicator: false)
    }
    
    // MARK: - ACTION
    
    // Action to manages the data received by the API, show activity indicator and hide button
    @IBAction func tappedValidButton(_ sender: Any) {
        index = languagePickerView.selectedRow(inComponent: 0)
        guard text.text != "" else {
            alert(title: "Erreur", message: "Aucun texte saisi !")
            return
        }
        activityIndicator(activityIndicator: activityIndicatorButton, button: validButton, showActivityIndicator: true)
        translateService.getTranslate(language: language, text: text.text ?? "") { [unowned self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let translatedText):
                    self.refreshScreen(data: translatedText, textView: self.translation)
                case .failure:
                    self.alert(title: "Erreur", message: "Une erreur est survenue, vérifier la votre saisie et la connexion internet !")
                }
                self.activityIndicator(activityIndicator: self.activityIndicatorButton, button: self.validButton, showActivityIndicator: false)
            }
        }
    }

    // MARK: - METHODS
    
    // Method to change the label language to match with the pickerView selected
    private func changeLanguage(index: Int) {
        switch index {
        case 0:
            sourceLabel.text = "Français"
            targetLabel.text = "Anglais"
            language = .fr
        case 1:
            sourceLabel.text = "Anglais"
            targetLabel.text = "Français"
            language = .en
        case 2:
            sourceLabel.text = "Detection"
            targetLabel.text = "Français"
            language = .detect
        default:
            break
        }
    }
    
    // Method to display result of translation in the textView
    private func refreshScreen(data: Translate, textView: UITextView) {
        textView.text = data.data.translations[0].translatedText
        textView.centerVertically()
    }
}

// MARK: - EXTENSIONS

// Extension for pickerView
extension TranslateViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    /// Method to return the number's colum of the UIPickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    /// Method to return the number of lines in the UIPickerView
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return translateService.language.count
    }
    
    /// Method to returns the value corresponding to the pickerView, change color text in white
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        print(row)
        changeLanguage(index: row)
        return NSAttributedString(string: translateService.language[row], attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
    }
}


// Extension to dismiss Keyboard
extension TranslateViewController: UITextFieldDelegate {
    @IBAction func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        text.resignFirstResponder()
    }
}


