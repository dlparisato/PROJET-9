//
//  WeatherViewController.swift
//  LE BALUCHON
//
//  Created by DL PARISATO on 15/06/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import UIKit

final class WeatherViewController: UIViewController {
    
    
    // MARK: OUTLETS
    
    // Cities
    @IBOutlet private var citieTextFields: [UITextField]!
    
    // Weather Image
    @IBOutlet private var weatherImageViews: [UIImageView]!
    
    // Temperature
    @IBOutlet private var temperatureLabels: [UILabel]!
    
    // Information weather
    @IBOutlet private var informationStackViews: [UIStackView]!
    
    // Button and Activity indicator
    @IBOutlet private weak var validButton: UIButton!
    @IBOutlet private weak var activityIndicatorView: UIActivityIndicatorView!
    
    
    // MARK:- PROPERTY
    
    // Instance of the WeatherService class
    private let weatherService = WeatherService()
    
    
    // MARK: - VIEW LIFE CYCLE
    
    // Update weather for New York and Paris
    override func viewDidLoad() {
        updateWeather()
    }
    
    
    // MARK: - ACTION
    
    // Get data with the API
    @IBAction private func tappedValidButton(_ sender: Any) {
        updateWeather()
    }
    
    
    // MARK: - METHODS
    
    // Pour obtenir des données avec API
    private func updateWeather() {
        defaultSetting()
        for i in 0...1 {
            weatherService.getWeather(from: citieTextFields[i].text ?? "") { [unowned self] result in
                DispatchQueue.main.async {
                    switch result {
                    case.success(let weather):
                        self.displayScreen(data: weather, index: i)
                    case .failure:
                        self.alert(title: "Erreur", message: "Une erreur est survenue. Vérifier la ville saisie et la connexion internet")
                    }
                }
            }
        }
        activityIndicator(activityIndicator: activityIndicatorView, button: validButton, showActivityIndicator: false)
    }
    
    // Default settings
    private func defaultSetting() {
        if citieTextFields[0].text == "" {
            citieTextFields[0].text = "New York"
        } else if citieTextFields[1].text == "" {
            citieTextFields[1].text = "Paris"
        }
    }
    
    // Display informations
    private func displayScreen(data: WeatherInfo, index: Int) {
        informationStackViews[index].isHidden = false
        temperatureLabels[index].text = convertToString(value: data.main.temp) + "°C"
        weatherImageViews[index].isHidden = false
        weatherImageViews[index].image = WeatherView.icon[data.weather[0].main]
    }
}


// MARK: - Extension with action to dismiss keyboard

extension WeatherViewController: UITextFieldDelegate {
    @IBAction func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        citieTextFields[0].resignFirstResponder()
        citieTextFields[1].resignFirstResponder()
    }
}
