//
//  TranslateServiceTests.swift
//  LE BALUCHONTests
//
//  Created by PARISATO on 30/07/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import XCTest
@testable import LE_BALUCHON

class WeatherServiceTests: XCTestCase {
    
    
    // Callback returns an error
    func testTranslateShouldPostFailedCallbackIfError() {
        /// Given
        let weather = WeatherService(weatherSession: URLSessionFake(data: nil, response: nil, error: FakeResponseData.error))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        weather.getWeather(from: "Paris") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback doesn't return data
    func testTranslateShouldPostFailedCallbackIfNoData() {
        /// Given
        let weather = WeatherService(weatherSession: URLSessionFake(data: nil, response: nil, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        weather.getWeather(from: "Paris") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback returns an incorrect response
    func testTranslateShouldPostFailedCallbackIncorrectResponse() {
        /// Given
        let weather = WeatherService(weatherSession: URLSessionFake(data: FakeResponseData.translateCorrectData, response: FakeResponseData.responseKO, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        weather.getWeather(from: "Paris") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback returns incorrect data
    func testTranslateShouldPostFailedCallbackIncorrectData() {
        /// Given
        let weather = WeatherService(weatherSession: URLSessionFake(data: FakeResponseData.IncorrectData, response: FakeResponseData.responseOK, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        weather.getWeather(from: "Paris") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback returns success with no error and correct data
    func testTranslateShouldPostSuccessCallbackIfNoErrorAndCorrectData() {
        /// Given
        let weather = WeatherService(weatherSession: URLSessionFake(data: FakeResponseData.weatherCorrectData, response: FakeResponseData.responseOK, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        weather.getWeather(from: "Paris") { result in
            /// Then
            guard case .success (let weather) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            let fakeWeatherTemp: Float = 20.43
            let fakeWeather: String = "Clear"
            
            XCTAssertEqual(fakeWeatherTemp, weather.main.temp)
            XCTAssertEqual(fakeWeather, weather.weather[0].main)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
}

