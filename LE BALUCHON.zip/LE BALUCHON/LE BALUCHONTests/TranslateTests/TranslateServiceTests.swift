//
//  TranslateServiceTests.swift
//  LE BALUCHONTests
//
//  Created by PARISATO on 30/07/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import XCTest
@testable import LE_BALUCHON

class TranslateServiceTests: XCTestCase {
    
    
    // Callback return error
    func testTranslateShouldPostFailedCallbackIfError() {
        /// Given
        let translate = TranslateService(translateSession: URLSessionFake(data: nil, response: nil, error: FakeResponseData.error))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        translate.getTranslate(language: .fr, text: "Bonjour") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback doesn't return data
    func testTranslateShouldPostFailedCallbackIfNoData() {
        /// Given
        let translate = TranslateService(translateSession: URLSessionFake(data: nil, response: nil, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        translate.getTranslate(language: .fr, text: "Bonjour") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback return incorrect response
    func testTranslateShouldPostFailedCallbackIncorrectResponse() {
        /// Given
        let translate = TranslateService(translateSession: URLSessionFake(data: FakeResponseData.translateCorrectData, response: FakeResponseData.responseKO, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        translate.getTranslate(language: .fr, text: "Bonjour") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback return incorrect data
    func testTranslateShouldPostFailedCallbackIncorrectData() {
        /// Given
        let translate = TranslateService(translateSession: URLSessionFake(data: FakeResponseData.IncorrectData, response: FakeResponseData.responseOK, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        translate.getTranslate(language: .fr, text: "Bonjour") { result in
            /// Then
            guard case .failure(let error) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            XCTAssertNotNil(error)
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback success with no error and correct data source french
    func testTranslateShouldPostSuccessCallbackIfNoErrorAndCorrectData() {
        /// Given
        let translate = TranslateService(translateSession: URLSessionFake(data: FakeResponseData.translateCorrectData, response: FakeResponseData.responseOK, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        translate.getTranslate(language: .fr, text: "Bonjour") { result in
            /// Then
            guard case .success(let resultTranslate) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            XCTAssertEqual(resultTranslate.data.translations[0].translatedText, "Hello")
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback success with no error and correct data source english
    func testTranslateShouldPostSuccessCallbackIfNoErrorAndCorrectDataSourceEnglish() {
        /// Given
        let translate = TranslateService(translateSession: URLSessionFake(data: FakeResponseData.translateCorrectDataEnglish, response: FakeResponseData.responseOK, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        translate.getTranslate(language: .en, text: "Hello") { result in
            /// Then
            guard case .success(let resultTranslate) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            XCTAssertEqual(resultTranslate.data.translations[0].translatedText, "Salut")
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }
    
    // Callback success with no error and correct data source english
    func testTranslateShouldPostSuccessCallbackIfNoErrorAndCorrectDataSourceDetect() {
        /// Given
        let translate = TranslateService(translateSession: URLSessionFake(data: FakeResponseData.translateCorrectDataDetect, response: FakeResponseData.responseOK, error: nil))
        /// When
        let expectation = XCTestExpectation(description: "Wait for queue change.")
        
        translate.getTranslate(language: .detect, text: "Gracias") { result in
            /// Then
            guard case .success(let result) = result else {
                XCTFail("Test request method with an error failed.")
                return
            }
            XCTAssertEqual(result.data.translations[0].translatedText, "Merci")
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 0.01)
    }

}

