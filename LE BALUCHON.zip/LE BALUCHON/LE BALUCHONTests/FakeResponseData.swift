//
//  FakeResponseData.swift
//  LE BALUCHONTests
//
//  Created by DL PARISATO on 28/06/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class FakeResponseData {
    
    // MARK: DATA
    
    
    // Weather
    static var weatherCorrectData: Data? {
        let bundle = Bundle(for: FakeResponseData.self)
        let url = bundle.url(forResource: "Weather", withExtension: "json")!
        return try? Data(contentsOf: url)
    }
    
    // Translate
    static var translateCorrectData: Data? {
        let bundle = Bundle(for: FakeResponseData.self)
        let url = bundle.url(forResource: "Translate", withExtension: "json")!
        return try? Data(contentsOf: url)
    }
    
    static var translateCorrectDataEnglish: Data? {
        let bundle = Bundle(for: FakeResponseData.self)
        let url = bundle.url(forResource: "TranslateEnglish", withExtension: "json")!
        return try? Data(contentsOf: url)
    }
    
    static var translateCorrectDataDetect: Data? {
        let bundle = Bundle(for: FakeResponseData.self)
        let url = bundle.url(forResource: "TranslateDetection", withExtension: "json")!
        return try? Data(contentsOf: url)
    }
    
    // Currency
    static var currencyCorrectData: Data? {
        let bundle = Bundle(for: FakeResponseData.self)
        let url = bundle.url(forResource: "Currency", withExtension: "json")!
        return try? Data(contentsOf: url)
    }
    
    static let IncorrectData = "erreur".data(using: .utf8)
    
    // MARK: - Response
    
    static let responseOK = HTTPURLResponse(
        url: URL(string: "https://openclassrooms.com")!,
        statusCode: 200, httpVersion: nil, headerFields: [:])!
    
    static let responseKO = HTTPURLResponse(
        url: URL(string: "https://openclassrooms.com")!,
        statusCode: 500, httpVersion: nil, headerFields: [:])!
    
    
    // MARK: - Error
    class testError: Error {}
    static let error = testError()
}
